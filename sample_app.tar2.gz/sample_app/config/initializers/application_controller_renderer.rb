# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '6d08aa340606a9aacfda072ee721275912df7f91287575257fc74b3c5aa025110fe292ab38b18649a442c930207c27e182c8a484f7248293cf6284251ea012ab'